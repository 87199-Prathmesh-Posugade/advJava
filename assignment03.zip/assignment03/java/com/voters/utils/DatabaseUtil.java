package com.voters.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseUtil {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/votingsystem";
	public static final String DB_USER = "root";
	public static final String DB_PASSWD = "manager";

	static {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.exit(1);
			e.printStackTrace();
		}
	}

	public static Connection getCon() throws Exception {
		Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);
		return con;
	}

}
